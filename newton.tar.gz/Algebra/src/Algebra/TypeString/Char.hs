{-# LANGUAGE EmptyDataDecls #-}
module Algebra.TypeString.Char where

data A_
instance Show A_ where show _ = "a"

data B_
instance Show B_ where show _ = "b"

data C_
instance Show C_ where show _ = "c"

data D_
instance Show D_ where show _ = "d"

data E_
instance Show E_ where show _ = "e"

data F_
instance Show F_ where show _ = "f"

data G_
instance Show G_ where show _ = "g"

data H_
instance Show H_ where show _ = "h"

data I_
instance Show I_ where show _ = "i"

data J_
instance Show J_ where show _ = "j"

data K_
instance Show K_ where show _ = "k"

data L_
instance Show L_ where show _ = "l"

data M_
instance Show M_ where show _ = "m"

data N_
instance Show N_ where show _ = "n"

data O_
instance Show O_ where show _ = "o"

data P_
instance Show P_ where show _ = "p"

data Q_
instance Show Q_ where show _ = "q"

data R_
instance Show R_ where show _ = "r"

data S_
instance Show S_ where show _ = "s"

data T_
instance Show T_ where show _ = "t"

data U_
instance Show U_ where show _ = "u"

data V_
instance Show V_ where show _ = "v"

data W_
instance Show W_ where show _ = "w"

data X_
instance Show X_ where show _ = "x"

data Y_
instance Show Y_ where show _ = "y"

data Z_
instance Show Z_ where show _ = "z"

data A
instance Show A where show _ = "A"

data B
instance Show B where show _ = "B"

data C
instance Show C where show _ = "C"

data D
instance Show D where show _ = "D"

data E
instance Show E where show _ = "E"

data F
instance Show F where show _ = "F"

data G
instance Show G where show _ = "G"

data H
instance Show H where show _ = "H"

data I
instance Show I where show _ = "I"

data J
instance Show J where show _ = "J"

data K
instance Show K where show _ = "K"

data L
instance Show L where show _ = "L"

data M
instance Show M where show _ = "M"

data N
instance Show N where show _ = "N"

data O
instance Show O where show _ = "O"

data P
instance Show P where show _ = "P"

data Q
instance Show Q where show _ = "Q"

data R
instance Show R where show _ = "R"

data S
instance Show S where show _ = "S"

data T
instance Show T where show _ = "T"

data U
instance Show U where show _ = "U"

data V
instance Show V where show _ = "V"

data W
instance Show W where show _ = "W"

data X
instance Show X where show _ = "X"

data Y
instance Show Y where show _ = "Y"

data Z
instance Show Z where show _ = "Z"
