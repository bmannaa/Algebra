module Main where
import qualified Tools.NewtonMain
main :: IO ()
main = Tools.NewtonMain.main
