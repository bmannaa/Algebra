module Q_Examples where

import Algebra.Q
